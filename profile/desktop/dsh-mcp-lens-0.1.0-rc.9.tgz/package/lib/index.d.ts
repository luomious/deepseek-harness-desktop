import z from "@deepseek-ai/schemastery";
import { CallToolResult, Tool } from "@modelcontextprotocol/sdk/types.js";
import { Context } from "@deepseek-ai/cordis";
//#region src/pool.d.ts
interface CommonServerConfig {
  /** Stable name used to address this server from the two public tools. */
  name: string;
  /** Optional non-secret scope used by the catalog fingerprint layer. */
  cacheNamespace?: string;
  /** Maximum MCP initialize handshake time. Defaults to 15 seconds. */
  connectTimeoutMs?: number;
  /** Maximum time for one tools/list page or tools/call request. Defaults to 60 seconds. */
  callTimeoutMs?: number;
  /** Close an unused connection after this many milliseconds. Zero closes immediately. */
  idleTimeoutMs?: number;
}
interface StdioServerConfig extends CommonServerConfig {
  transport: 'stdio';
  command: string;
  args?: readonly string[];
  /** Explicit child environment layered over Harness' scrubbed parent environment. */
  env?: Readonly<Record<string, string>>;
  cwd?: string;
}
interface StreamableHttpServerConfig extends CommonServerConfig {
  transport: 'streamable-http';
  url: string;
  headers?: Readonly<Record<string, string>>;
}
/** One configured MCP server. Connections are created only on first use. */
type ServerConfig = StdioServerConfig | StreamableHttpServerConfig;
/** An MCP tool with the local server identity needed for an exact call. */
type RemoteTool = Tool & {
  readonly server: string;
};
/** The unprojected MCP call result, including every content block and structuredContent. */
type RemoteCallResult = CallToolResult;
interface ConnectionPoolOptions {
  /** Called when a server explicitly announces tools/list_changed. */
  onCatalogInvalidated?: (server: string) => void;
  /** Overall wall-clock deadline for one full paginated discovery. */
  discoveryTimeoutMs?: number;
  /** Maximum tools/list pages accepted from one discovery. */
  maxDiscoveryPages?: number;
  /** Maximum tools accepted from one server. */
  maxToolsPerServer?: number;
  /** Maximum UTF-8 JSON bytes accepted for one tool definition. */
  maxBytesPerTool?: number;
  /** Maximum UTF-8 JSON bytes across the latest discovered catalogs in this pool. */
  maxTotalCatalogBytes?: number;
  /** Maximum decoded bytes accepted from each Streamable HTTP response. */
  maxHttpResponseBytes?: number;
  /** Maximum UTF-8 bytes accepted for one opaque tools/list cursor. */
  maxCursorBytes?: number;
}
/**
 * Lazy, bounded MCP connection pool used by the fixed `mcp_search` and
 * `mcp_call` surface. It deliberately never registers remote tools in DSH.
 */
declare class ConnectionPool {
  #private;
  constructor(configs: readonly ServerConfig[], options?: ConnectionPoolOptions);
  /** Configured server names in deterministic configuration order. */
  serverNames(): string[];
  /** Drain every tools/list page and retain the complete MCP tool metadata. */
  listTools(server: string, signal?: AbortSignal): Promise<RemoteTool[]>;
  /** Call one exact remote tool while preserving the protocol result as JSON. */
  callTool(server: string, tool: string, args: Readonly<Record<string, unknown>>, signal?: AbortSignal): Promise<RemoteCallResult>;
  /**
   * Abort work, close all generations, and wait for in-flight operations to
   * settle. Repeated calls share the same teardown promise.
   */
  dispose(): Promise<void>;
}
//#endregion
//#region src/catalog.d.ts
declare const CATALOG_CACHE_FORMAT: "dsh-mcp-lens/catalog";
declare const CATALOG_CACHE_FORMAT_VERSION: 1;
declare const DEFAULT_MAX_SNAPSHOT_BYTES: number;
declare const DEFAULT_MAX_TOOLS_PER_SERVER = 10000;
declare const DEFAULT_MAX_BYTES_PER_TOOL = 1048576;
type JsonPrimitive = boolean | number | string | null;
type JsonValue = JsonPrimitive | JsonObject | readonly JsonValue[];
interface JsonObject {
  readonly [key: string]: JsonValue;
}
/**
 * JSON-safe metadata returned by MCP `tools/list`.
 *
 * This is an intentional projection of MCP `Tool`: full input schemas are
 * retained, while response schemas, icons, `_meta`, and unknown top-level
 * fields are discarded before either memory indexing or disk persistence.
 */
interface CatalogTool {
  readonly name: string;
  readonly title?: string;
  readonly description?: string;
  /** Runtime validation guarantees JSON; the broad object type accepts MCP SDK Tool directly. */
  readonly inputSchema: Readonly<Record<string, unknown>>;
  readonly annotations?: Readonly<Record<string, unknown>>;
  readonly execution?: Readonly<Record<string, unknown>>;
}
/** Backwards-compatible descriptive alias. */
type McpToolMetadata = CatalogTool;
interface ConfiguredServer {
  readonly name: string;
  readonly fingerprint: string;
}
interface CatalogServerSnapshot extends ConfiguredServer {
  /** Epoch milliseconds when the complete tools/list generation was fetched. */
  readonly fetchedAt: number;
  readonly tools: readonly McpToolMetadata[];
}
interface CatalogSnapshot {
  readonly format: typeof CATALOG_CACHE_FORMAT;
  readonly formatVersion: typeof CATALOG_CACHE_FORMAT_VERSION;
  /** Monotonic logical revision of the catalog contents. */
  readonly revision: number;
  readonly servers: readonly CatalogServerSnapshot[];
}
interface CatalogSearchOptions {
  readonly limit?: number;
  readonly server?: string;
}
interface CatalogToolFilter {
  allows(server: string, tool: string): boolean;
}
interface CatalogSearchResult {
  readonly server: string;
  readonly fingerprint: string;
  readonly tool: McpToolMetadata;
  readonly score: number;
  readonly matchedTerms: readonly string[];
}
type CacheLoadStatus = 'loaded' | 'missing' | 'corrupt' | 'incompatible' | 'oversized' | 'limit-exceeded' | 'superseded';
interface CacheLoadResult {
  readonly status: CacheLoadStatus;
  readonly snapshot: CatalogSnapshot;
}
interface CatalogSizeOptions {
  /** Maximum UTF-8 bytes of canonical cache JSON, including its final newline. */
  readonly maxSnapshotBytes?: number;
  /** Maximum number of projected tools retained for one server generation. */
  readonly maxToolsPerServer?: number;
  /** Maximum canonical UTF-8 JSON bytes of one projected tool, with no trailing newline. */
  readonly maxBytesPerTool?: number;
}
declare class CatalogSnapshotTooLargeError extends RangeError {
  readonly actualBytes: number;
  readonly maxBytes: number;
  constructor(actualBytes: number, maxBytes: number);
}
declare class CatalogServerToolLimitError extends RangeError {
  readonly server: string;
  readonly actualTools: number;
  readonly maxTools: number;
  constructor(server: string, actualTools: number, maxTools: number);
}
declare class CatalogToolTooLargeError extends RangeError {
  readonly server: string;
  readonly tool: string;
  readonly actualBytes: number;
  readonly maxBytes: number;
  constructor(server: string, tool: string, actualBytes: number, maxBytes: number);
}
/** Endpoint material that is safe to use for identity derivation. */
type ServerEndpointIdentity = {
  readonly name: string;
  readonly transport: 'stdio';
  readonly command: string;
  readonly args?: readonly string[];
  readonly cwd?: string;
  readonly cacheNamespace?: string;
} | {
  readonly name: string;
  readonly transport: 'http' | 'streamable-http';
  readonly url: string;
  readonly cacheNamespace?: string;
};
/**
 * Create a stable endpoint identity without persisting endpoint configuration.
 *
 * Headers, environment variables, URL credentials, and query values are
 * deliberately excluded: not even a digest derived from a secret is written
 * to cache. Endpoint path and non-secret process argv still invalidate stale
 * tool metadata. Credential-shaped command-line flag values are redacted
 * before hashing as a final defense for servers that do not use `env`.
 */
declare function serverFingerprint(endpoint: ServerEndpointIdentity): string;
/** Project a pool RemoteTool to the cache-safe metadata allowlist. */
declare function catalogToolFromRemote(remoteTool: unknown): CatalogTool;
/**
 * Exact per-tool budget unit: UTF-8 bytes of `JSON.stringify()` applied to the
 * cache-safe projected tool, with deterministic top-level field order and no
 * whitespace or trailing newline.
 */
declare function catalogToolUtf8Bytes(remoteOrProjectedTool: unknown): number;
/** Return an immutable empty catalog. */
declare function emptyCatalog(revision?: number): CatalogSnapshot;
/**
 * Search an immutable snapshot using deterministic exact-field IDF ranking.
 *
 * The exact route uses canonical tokens, best-field scoring, corpus rarity,
 * field-length normalization, and a bounded coverage bonus. Only when that
 * route is empty may one eligible Latin OOV term use true edit-distance-one
 * fallback against name/title tokens. Prefix, substring, transposition,
 * description, and schema fuzzy matches are never used.
 */
declare function searchCatalog(snapshot: CatalogSnapshot, query: string, options?: CatalogSearchOptions): readonly CatalogSearchResult[];
/**
 * Filter one immutable catalog generation once per stable policy identity.
 * Mutable caller-owned snapshots and policies are never identity-cached.
 */
declare function filterCatalog(snapshot: CatalogSnapshot, policy: CatalogToolFilter): CatalogSnapshot;
/**
 * Load, validate, and prune a cache against currently configured endpoints.
 * Invalid or unreadable data fails open as an empty catalog and never throws.
 */
declare function loadCatalogCache(cachePath: string, configuredServers: Iterable<ConfiguredServer>, options?: CatalogSizeOptions): Promise<CacheLoadResult>;
/** Atomically write a validated snapshot with owner-only file permissions. */
declare function writeCatalogCache(cachePath: string, snapshot: CatalogSnapshot, options?: CatalogSizeOptions): Promise<void>;
/**
 * Mutable facade whose every content update swaps one immutable generation.
 * Slow discovery from a previous endpoint cannot overwrite a reconfigured
 * server because `replaceServerTools` requires the current fingerprint.
 */
declare class ToolCatalog {
  #private;
  constructor(configuredServers?: Iterable<ConfiguredServer>, options?: CatalogSizeOptions);
  get revision(): number;
  get size(): number;
  get maxSnapshotBytes(): number;
  get maxToolsPerServer(): number;
  get maxBytesPerTool(): number;
  snapshot(): CatalogSnapshot;
  /** Replace the configured endpoint set and immediately prune stale tools. */
  configure(configuredServers: Iterable<ConfiguredServer>): void;
  /**
   * Atomically replace one server's tool generation.
   * Returns false for an unconfigured or stale endpoint instead of publishing it.
   */
  replaceServerTools(serverName: string, fingerprint: string, tools: readonly McpToolMetadata[], fetchedAt?: number): boolean;
  /** Ignore stale teardown events by optionally binding removal to a fingerprint. */
  removeServer(serverName: string, fingerprint?: string): boolean;
  get(serverName: string, toolName: string): McpToolMetadata | undefined;
  /** Whether this exact endpoint currently has a complete catalog generation. */
  isFresh(serverName: string, fingerprint: string): boolean;
  /**
   * Return true when an endpoint has no matching generation or its TTL elapsed.
   * Clock rollback is treated as stale rather than extending cache lifetime.
   */
  needsRefresh(serverName: string, fingerprint: string, ttlMs: number, now?: number): boolean;
  /** Remove one generation; stale fingerprint-bound invalidations are ignored. */
  invalidate(serverName: string, fingerprint?: string): boolean;
  search(query: string, options?: CatalogSearchOptions): readonly CatalogSearchResult[];
  /** Load only if no in-memory generation changed while disk I/O was pending. */
  load(cachePath: string): Promise<CacheLoadResult>;
  /** Serialize writes per catalog instance; each file replacement is atomic. */
  save(cachePath: string): Promise<void>;
}
//#endregion
//#region src/policy.d.ts
/** Fine-grained policy for capabilities hidden behind the single mcp_call tool. */
interface ToolPolicy {
  allows(server: string, tool: string): boolean;
  denialReason(server: string, tool: string): string;
}
/** Match a string against a tiny, auditable glob language: `*` and literals. */
declare function globMatches(pattern: string, value: string): boolean;
/** Compile allow/deny lists once. Deny always wins; an empty allow list allows nothing. */
declare function compileToolPolicy(allow: readonly string[], deny: readonly string[]): ToolPolicy;
//#endregion
//#region src/index.d.ts
declare const name = "mcp-lens";
declare const inject: string[];
interface Config {
  /** Trusted MCP endpoints. Nothing is contacted during plugin activation. */
  servers: ServerConfig[];
  /** Derived catalog cache. Projected server metadata is stored with mode 0600; configured connection secrets are never stored. */
  cachePath: string;
  /** Refresh a last-good catalog after this many milliseconds. Zero always refreshes. */
  catalogTtlMs: number;
  /** Retire an unused MCP connection after this many milliseconds. */
  idleDisconnectMs: number;
  /** Default initialize handshake timeout. A server may override it. */
  connectTimeoutMs: number;
  /** Default tools/list and tools/call timeout. A server may override it. */
  callTimeoutMs: number;
  /** Overall wall-clock deadline for one complete paginated tools/list discovery. */
  discoveryTimeoutMs: number;
  /** Maximum tools/list pages accepted in one discovery. */
  maxDiscoveryPages: number;
  /** Maximum number of tools accepted from one server. */
  maxToolsPerServer: number;
  /** Maximum UTF-8 JSON bytes accepted for one raw MCP tool definition. */
  maxBytesPerTool: number;
  /** Maximum UTF-8 JSON bytes across the latest accepted server catalogs. */
  maxTotalCatalogBytes: number;
  /** Maximum bytes accepted from one Streamable HTTP response body. */
  maxHttpResponseBytes: number;
  /** Maximum UTF-8 bytes accepted for one tools/list pagination cursor. */
  maxCursorBytes: number;
  /** Default number of relevant schemas returned by mcp_search. */
  searchLimitDefault: number;
  /** Hard cap on schemas returned by one mcp_search. */
  searchLimitMax: number;
  /** Allowed `server/tool` globs. The glob language has only `*` and literals. */
  allowTools: string[];
  /** Denied `server/tool` globs. Deny takes precedence. */
  denyTools: string[];
}
declare const Config: z<Config>;
/** Load the catalog, create the lazy pool, and register exactly two tools. */
declare function apply(ctx: Context, rawConfig: Config): Promise<void>;
//#endregion
export { CATALOG_CACHE_FORMAT, CATALOG_CACHE_FORMAT_VERSION, CacheLoadResult, CacheLoadStatus, CatalogSearchOptions, CatalogSearchResult, CatalogServerSnapshot, CatalogServerToolLimitError, CatalogSizeOptions, CatalogSnapshot, CatalogSnapshotTooLargeError, CatalogTool, CatalogToolFilter, CatalogToolTooLargeError, Config, ConfiguredServer, ConnectionPool, ConnectionPoolOptions, DEFAULT_MAX_BYTES_PER_TOOL, DEFAULT_MAX_SNAPSHOT_BYTES, DEFAULT_MAX_TOOLS_PER_SERVER, JsonObject, JsonPrimitive, JsonValue, McpToolMetadata, RemoteCallResult, RemoteTool, ServerConfig, ServerEndpointIdentity, StdioServerConfig, StreamableHttpServerConfig, ToolCatalog, ToolPolicy, apply, catalogToolFromRemote, catalogToolUtf8Bytes, compileToolPolicy, emptyCatalog, filterCatalog, globMatches, inject, loadCatalogCache, name, searchCatalog, serverFingerprint, writeCatalogCache };
//# sourceMappingURL=index.d.ts.map